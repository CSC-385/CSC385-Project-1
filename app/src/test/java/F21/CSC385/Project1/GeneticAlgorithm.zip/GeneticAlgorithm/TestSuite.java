package F21.CSC385.Project1.GeneticAlgorithm;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        FactoryFloorTest.class,
        StationTest.class
})

public class TestSuite {
}
